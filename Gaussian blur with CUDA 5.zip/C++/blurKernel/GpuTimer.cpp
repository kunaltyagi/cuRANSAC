#include "stdafx.h"
#include "GpuTimer.h"
